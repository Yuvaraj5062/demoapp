import React from 'react'
import Button from "../button/Button";
import styles from "./characterCommitmentCard.module.scss"

const CharacterCommitmentCard = ({ characterCommitmentImg, characterCommitmentTitle, characterCommitmentInfo,characterCommitmentBtn }) => {
    return (
        <>
            <div className={styles.CharacterCommitmentContainer}>
                <img src={characterCommitmentImg} className={styles.characterCommitmentImg} />

                <div className={styles.CharacterCommitmentContent}>
                <p className={styles.characterCommitmentTitle}>{characterCommitmentTitle}
                </p>
                <p className={styles.characterCommitmentInfo}>{characterCommitmentInfo}</p>
               
            </div>
            
            <Button
                    title={characterCommitmentBtn}
                    customClass={styles.commitmentBtn}
                    customClassForText={styles.CommitmentBtnText}
                />
            </div>
        </>
    )
}

export default CharacterCommitmentCard